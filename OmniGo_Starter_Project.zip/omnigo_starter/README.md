# OmniGo — Bangladesh-first Super App starter

This is a **buildable starter scaffold**, not a finished production marketplace. It includes:
- Flutter Android + Web app shell
- Customer / Provider entry choices and four main navigation tabs
- Node.js API starter (`/health`)
- PostgreSQL starter schema
- GitHub Actions workflow for Flutter analysis/tests and Android/Web builds
- Explicit payment adapter placeholder that does **not** claim to process real money

## Stack
- Flutter stable (Android + Web)
- Node.js + Express API
- PostgreSQL
- Firebase Authentication planned for phone OTP, Google, and email
- Payment gateways must be integrated only after merchant approval and provider credentials

## Build the Flutter app
Install Flutter SDK and Android tooling, then:
```bash
cd apps/omnigo
flutter pub get
flutter analyze
flutter test
flutter run -d chrome
flutter build web
flutter build apk --debug
```

For Android release APK:
```bash
flutter build apk --release
```
Release signing is intentionally not configured. Never commit keystores or passwords.

## Run the API
Requires Node.js 20+:
```bash
cd services/api
npm install
cp .env.example .env
npm run dev
```
Open `http://localhost:3000/health`.

## Database
Create a PostgreSQL database and apply `services/api/db/schema.sql` with your preferred migration tool.
The included schema is a starter baseline, not a complete final schema.

## Firebase authentication setup
1. Create a Firebase project.
2. Add Android and Web apps in Firebase Console.
3. Enable Phone, Google, and Email/Password sign-in providers.
4. Configure authorized domains, Android package name, SHA-1/SHA-256, and SMS region policy.
5. Add Flutter Firebase packages and generated Firebase options using FlutterFire CLI.
6. Link accounts carefully so phone/email/Google sign-ins for the same person do not create accidental duplicate accounts.
7. Add server-side authorization; never trust a client-supplied role.

Firebase phone OTP may incur SMS charges and requires appropriate anti-abuse settings. Use Firebase test phone numbers only in development.

## Bangladesh location data
Seed and maintain administrative data from official sources. The National Portal currently publishes division, district and upazila lists:
- https://bangladesh.gov.bd/views/division-list
- https://bangladesh.gov.bd/views/district-list/
- https://bangladesh.gov.bd/views/upazila-list

Do not hard-code a claim that every thana/area is an official administrative unit. Model upazilas, metropolitan police thanas, unions, wards and locality/neighborhood as distinct types and update the dataset through an admin-reviewed import.

## Payment safety
The current `PaymentGateway` API is an interface only. It does not contact bKash, Nagad, Rocket, or banks.
Before live payments:
- obtain merchant onboarding/approval and official API credentials from each provider
- implement server-to-server checkout, signature/token validation, idempotency, webhook verification, reconciliation, refund flow and audit logs
- never store PINs, OTPs, card credentials, or payment secrets in the app
- mark orders paid only after verified gateway confirmation
- use sandbox credentials and label all test payments as test
- review local legal, tax, consumer protection and payment rules

## GitHub Actions
Push this repository to GitHub. The workflow at `.github/workflows/ci.yml` runs Flutter analysis/tests and builds Android debug APK and web output.
It does not publish to app stores or deploy the site automatically.

## Production gaps before launch
- Real Firebase integration and account linking
- API authentication middleware and RBAC
- Provider document storage and review queue
- Actual PostgreSQL migrations, repositories, validation and rate limits
- Search, booking lifecycle, order inventory, ride dispatch and maps
- Real gateway integrations and reconciliation
- Privacy policy, terms, consent, data retention, incident response
- Automated security and integration tests
