import 'package:flutter/material.dart';

void main() {
  runApp(const OmniGoApp());
}

class OmniGoApp extends StatelessWidget {
  const OmniGoApp({super.key});

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF087F5B);
    return MaterialApp(
      title: 'OmniGo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F9F8),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Color(0xFF10251D),
          centerTitle: false,
        ),
      ),
      home: const EntryScreen(),
    );
  }
}

class EntryScreen extends StatelessWidget {
  const EntryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(Icons.hub_rounded, size: 68, color: Color(0xFF087F5B)),
                  const SizedBox(height: 12),
                  const Text('OmniGo',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 36, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  const Text('One App. Everything Connected.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.black54)),
                  const SizedBox(height: 36),
                  FilledButton.icon(
                    icon: const Icon(Icons.person_outline),
                    label: const Text('Continue as Customer'),
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const MainShell()),
                    ),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.handyman_outlined),
                    label: const Text('Register as Provider'),
                    onPressed: () => showDialog<void>(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text('Provider registration'),
                        content: const Text(
                          'Starter UI only. Production onboarding must collect service category, '
                          'service areas, identity documents and consent, then wait for admin approval.',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('Close'),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  const Text(
                    'Demo shell — authentication, payments, booking and marketplace APIs are not connected yet.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selectedIndex = 0;

  static const pages = [
    HomeTab(),
    ServicesTab(),
    ShopTab(),
    RideTab(),
    ProfileTab(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('OmniGo'),
        actions: [
          IconButton(
            tooltip: 'Notifications',
            onPressed: () => _notice('Notifications will be connected to the API.'),
            icon: const Icon(Icons.notifications_none),
          ),
        ],
      ),
      body: pages[selectedIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (index) => setState(() => selectedIndex = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.handyman_outlined), label: 'Services'),
          NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), label: 'Shop'),
          NavigationDestination(icon: Icon(Icons.two_wheeler_outlined), label: 'Ride'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }

  void _notice(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('What do you need today?',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text('Choose an area to see available services and providers.'),
        const SizedBox(height: 16),
        const TextField(
          decoration: InputDecoration(
            prefixIcon: Icon(Icons.search),
            hintText: 'Search products, services, professionals',
            border: OutlineInputBorder(),
            filled: true,
            fillColor: Colors.white,
          ),
        ),
        const SizedBox(height: 18),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: const [
            _CategoryChip(icon: Icons.electrical_services, label: 'Electrician'),
            _CategoryChip(icon: Icons.ac_unit, label: 'AC repair'),
            _CategoryChip(icon: Icons.medical_services_outlined, label: 'Doctor'),
            _CategoryChip(icon: Icons.plumbing, label: 'Plumber'),
            _CategoryChip(icon: Icons.shopping_bag_outlined, label: 'Shopping'),
            _CategoryChip(icon: Icons.two_wheeler, label: 'Bike ride'),
          ],
        ),
        const SizedBox(height: 24),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('Local services, made simpler',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Text('Live provider availability will appear after location and API setup.'),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _CategoryChip extends StatelessWidget {
  const _CategoryChip({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Chip(
      avatar: Icon(icon, size: 18),
      label: Text(label),
      backgroundColor: Colors.white,
      side: BorderSide(color: Colors.green.shade100),
    );
  }
}

class ServicesTab extends StatelessWidget {
  const ServicesTab({super.key});

  @override
  Widget build(BuildContext context) => const _PlaceholderTab(
        icon: Icons.handyman_outlined,
        title: 'Services',
        message: 'Provider search, area filters, pricing and booking lifecycle are planned API features.',
      );
}

class ShopTab extends StatelessWidget {
  const ShopTab({super.key});

  @override
  Widget build(BuildContext context) => const _PlaceholderTab(
        icon: Icons.storefront_outlined,
        title: 'Marketplace',
        message: 'Multi-seller catalog, cart, stock, checkout, order tracking and returns need backend integration.',
      );
}

class RideTab extends StatelessWidget {
  const RideTab({super.key});

  @override
  Widget build(BuildContext context) => const _PlaceholderTab(
        icon: Icons.two_wheeler_outlined,
        title: 'Ride',
        message: 'Ride booking, fare estimates, driver dispatch and live tracking require maps and backend services.',
      );
}

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  @override
  Widget build(BuildContext context) => const _PlaceholderTab(
        icon: Icons.person_outline,
        title: 'Profile',
        message: 'Sign-in, account linking, order history, provider onboarding and subscription will be connected next.',
      );
}

class _PlaceholderTab extends StatelessWidget {
  const _PlaceholderTab({
    required this.icon,
    required this.title,
    required this.message,
  });
  final IconData icon;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 480),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 56, color: const Color(0xFF087F5B)),
              const SizedBox(height: 12),
              Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(message, textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}
