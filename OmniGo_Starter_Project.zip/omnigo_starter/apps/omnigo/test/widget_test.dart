import 'package:flutter_test/flutter_test.dart';
import 'package:omnigo/main.dart';

void main() {
  testWidgets('shows OmniGo entry screen', (tester) async {
    await tester.pumpWidget(const OmniGoApp());
    expect(find.text('OmniGo'), findsOneWidget);
    expect(find.text('Continue as Customer'), findsOneWidget);
    expect(find.text('Register as Provider'), findsOneWidget);
  });
}
