/**
 * Interface placeholder only.
 * This module does not process money and is NOT a live bKash/Nagad/Rocket/bank integration.
 * Implement each provider from its official merchant documentation after approval.
 */
class PaymentGateway {
  async createCheckout(_request) {
    throw new Error('Payment gateway is not configured. No real payment was attempted.');
  }

  async verifyWebhook(_headers, _rawBody) {
    throw new Error('Webhook verification is not configured.');
  }

  async requestRefund(_request) {
    throw new Error('Refund integration is not configured.');
  }
}

module.exports = { PaymentGateway };
